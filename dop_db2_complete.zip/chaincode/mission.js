/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const { Contract } = require('fabric-contract-api');

class Missions extends Contract {

    async initLedger(ctx) {
        console.info('============= START : Initialize Ledger ===========');
        const mission = [
            {
                'postnumber': '10000',
                'title': 'bobododo',
                'company': {
                    "walking": "rororu",
                    'companyNo': '28192-192831-22212',
                    'companyAddrs': 'seoul',
                    'companyUrl': 'www.eieid.com'
                },
                'creatorEmail': 'skajhspd@naver.com',
                'missionRule': 'ruleoff',
                'missionUserNum': '30',
                'content': '코코코',
                'tag': '뽀인트, 쏘리초이',
                'inputGroupFile': 'url/doekd/29j9jdfsa/dmc.jpg',
                'startDate': '2019-10-10',
                'endDate': '2019-10-30',
                'survey': 'tatata',
                'survey2': 'hahaha',
                'survey3': 'kakaka'
            }
        ];

        for (let i = 0; i < mission.length; i++) {
            await ctx.stub.putState(mission[i].creator, Buffer.from(JSON.stringify(mission[i])));
            console.info('Added <--> ', mission[i]);
        }
        console.info('============= END : Initialize Ledger ===========');
    }



    async queryMission(ctx, postnumber) {
        const missionAsBytes = await ctx.stub.getState(postnumber); // get the car from chaincode state
        if (!missionAsBytes || missionAsBytes.length === 0) {
            throw new Error(`${postnumber} does not exist`);
        }
        console.log(missionAsBytes.toString());
        return missionAsBytes.toString();
    }

    // 미션 승인 및 렛저 등록
    async createMission(ctx, postnumber, title, company_id, managername, manageremail, missioncondition, missionusernum, content, tag, inputgroupfile, startdate, enddate, survey, survey2, survey3) {
        console.info('============= START : Create Missions ===========');

        const mission = {
            'postnumber': postnumber,
            'title': title,
            'company': {
                'companyId': company_id,
            },
            'manager': {
                'managerName': managername,
                'managerEmail': manageremail,
            },
            'missionRule': missioncondition,
            'content': content,
            'tag': tag,
            'inputGroupFile': inputgroupfile,
            'startDate': startdate,
            'endDate': enddate,
            'survey': survey,
            'survey2': survey2,
            'survey3': survey3,
            'missionState': 'active',   // 비활성/활성/완료
            'joiner': missionusernum,        // 미션 참가자
            'limitJoiner': "0"
        };
        const company = {

        };
        const users = {

        };
        const states = {

        };

        await ctx.stub.putState(postnumber, Buffer.from(JSON.stringify(mission)));
        console.info('============= END : Create Missons ===========');
    }

    async changeMissionTitle(ctx, postnumber, newTitle) {
        console.info('============= START : changeMissionTitle ===========');

        const missionAsBytes = await ctx.stub.getState(postnumber); // get the car from chaincode state
        if (!missionAsBytes || missionAsBytes.length === 0) {
            throw new Error(`${postnumber} does not exist`);
        }
        const mission = JSON.parse(missionAsBytes.toString());
        mission.title = newTitle;

        await ctx.stub.putState(postnumber, Buffer.from(JSON.stringify(mission)));
        console.info('============= END : changeMissionTitle ===========');
    }

    // 미션 사용자 참여, 미션완료 유무
    async addJoiner(ctx, postnumber, newUser) {
        console.info('============= START : addJoiner ===========');

        const missionState = await ctx.stub.getState(postnumber); // get the car from chaincode state
        if (!missionState || missionState.length === 0) {
            throw new Error(`${postnumber} does not exist`);
        }
        const mission = JSON.parse(missionState.toString());
        mission.jonier += newUser;

        await ctx.stub.putState(postnumber, Buffer.from(JSON.stringify(mission)));
        console.info('============= END : addJoiner ===========');
    }

    // 미션 승인
    async missionApprove(ctx, postnumber) {
        console.info('============= START : missionApprove ===========');

        const missionState = await ctx.stub.getState(postnumber); // get the car from chaincode state
        if (!missionState || missionState.length === 0) {
            throw new Error(`${postnumber} does not exist`);
        }
        const mission = JSON.parse(missionState.toString());
        mission.missionState = inactive;

        await ctx.stub.putState(postnumber, Buffer.from(JSON.stringify(mission)));
        console.info('============= END : missionApprove ===========');
    }
}

module.exports = Missions;