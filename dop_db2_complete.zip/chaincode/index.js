/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const Missions = require('./mission');

module.exports.Missions = Missions;
module.exports.contracts = [ Missions ];