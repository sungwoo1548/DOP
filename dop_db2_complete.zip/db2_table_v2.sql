create table knv93972.company_user (
    company_id varchar(32) not null,
    company_pw varchar(60) not null,
    company_email varchar(40) not null,
    company_tel varchar(20) not null,
    company_idennum varchar(40) not null,
    company_name varchar(32) not null,
    company_location varchar(60) not null,
    company_url varchar(80) DEFAULT null,
    company_category varchar(20) not null,
    primary key (
        company_id
    )
);


create table knv93972.missions_form (
    postNumber int NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
    company_id varchar(45) NOT NULL,
    title varchar(45) NOT NULL,
    managerName varchar(45) NOT NULL,
    managerEmail varchar(52) NOT NULL,
    missionCondition varchar(52) NOT NULL,
    missionUserNum int NOT NULL,
    content varchar(45) NOT NULL,
    inputGroupFile varchar(255) NOT NULL,
    startDate varchar(50) NOT NULL,
    endDate varchar(50) NOT NULL,
    survey varchar(45) DEFAULT NULL,
    survey2 varchar(45) DEFAULT NULL,
    survey3 varchar(45) DEFAULT NULL,
    tag varchar(45) DEFAULT NULL,
    dateTime timestamp(9) DEFAULT CURRENT_TIMESTAMP,
    adState varchar(45) NOT NULL DEFAULT 'waiting',
    primary key (
        postNumber
    ),
    FOREIGN KEY (company_id) REFERENCES knv93972.company_user(company_id) ON UPDATE RESTRICT ON DELETE CASCADE
);

-- ALTER TABLE missions_form
--     ALTER COLUMN inputGroupFile
--     SET DATA TYPE varchar(255);


-- create table knv93972.missions (
--     mission_no int not null default '0',
--     mission_name varchar(45) not null,
--     mission_tag clob not null default '(buy, eat, survey)',
--     mission_date date not null,
--     mission_start date not null,
--     mission_end date not null,
--     mission_personnel int not null,
--     mission_survey_num int not null default '3',
--     mission_survey_question blob not null,
--     mission_state varchar(10) not null,
--     company_id varchar(60),
--     manager_name varchar(45) not null,
--     manager_email varchar(60) not null,
--     manager_tel varchar(40) not null,
--     primary key (
--         mission_no
--     ),
--     FOREIGN KEY (company_id) REFERENCES knv93972.companys(company_id) ON UPDATE RESTRICT ON DELETE CASCADE,
--     FOREIGN KEY (manager_name, manager_email, manager_tel) REFERENCES knv93972.manager(manager_name, manager_email, manager_tel) ON UPDATE RESTRICT ON DELETE CASCADE
-- );
