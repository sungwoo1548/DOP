create table BJR81526.mission (
    mission_no int not null,
    mission_name varchar(20) not null,
    mission_rule varchar(60) not null,
    mission_joiner int,
    mission_detail varchar(255),
    mission_img varchar(225)
    mission_review numeric(1,1),
    mission_start date,
    mission_end date,
    primary key (
        mission_no
    )
);

create table BJR81526.company (
    company_no int not null,
    company_id varchar(20) not null,
    company_num binary not null,
    company_name varchar(40) not null,
    company_url varchar(100),
    company_type varchar(10),
    primary key (
        company_no,
        company_id,
        company_num
    )
);

create table BJR81526.manager (
    manager_name varchar(20) not null,
    manager_email varchar(60) not null,
    manager_tel varchar(15) not null,
    primary key (
        manager_email,
        manager_tel
    )
);

create table BJR81526.user (
    user_id varchar(40) not null,
     user_pwd varchar(255) not null,
     user_email varchar(60) not null,
     user_tel varchar(15) not null,

    primary key (
        user_id,
        user_tel
        )
);