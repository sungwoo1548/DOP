CREATE TABLE BJR81526.personal_info (
  person_no int NOT NULL,
  person_name VARCHAR(40) NOT NULL,
  person_tel varchar(15) NOT NULL,
  person_birth varchar(15) NOT NULL,
  PRIMARY KEY (person_no, person_name)
);
CREATE TABLE BJR81526.user_info (
  user_id int NOT NULL,
  user_pw VARCHAR(40) NOT NULL,
  user_img binary NOT NULL
);
create TABLE BJR81526.user_status (
  user_activation boolean default true,
  user_warningyellow boolean,
  user_warningred boolean,
  user_signup_date date NOT NULL,
  user_signin_date date not null
);
create TABLE BJR81526.user_accounts (
  user_account_no varchar(255) not null,
  user_balance binary not null,
  user_deposit int not null,
  user_withdraw int not null,
  user_history varchar(255) not null,
  PRIMARY key (
    user_account_no,
    user_balance,
    user_deposit,
    user_withdraw,
    user_history
  )
);
create TABLE BJR81526.company_info (
  company_no int not null,
  company_name varchar(60) not null,
  business_no int not null,
  business_no_file binary not null,
  company_ceo_name varchar(20) not null,
  company_address varchar(80) not null,
  company_tel varchar(15),
  company_email varchar(60) not null,
  PRIMARY key (company_no, company_name)
);
create TABLE BJR81526.company_manager_info (
  manager_name varchar(40) not null,
  manager_tel varchar(15) not null,
  manager_email varchar(80) not null,
  company_no int not null,
  FOREIGN KEY (company_no) REFERENCES BJR81526.company_info(company_no) ON UPDATE RESTRICT ON DELETE CASCADE
);
create TABLE BJR81526.company_status (
  company_activation boolean,
  company_warningyellow boolean,
  company_warningred boolean,
  company_signup_date date,
  company_signin_date date
);
create TABLE BJR81526.company_accounts (
  company_account_no varchar(255) not null,
  company_balance binary not null,
  company_deposit int not null,
  company_withdraw int not null,
  company_history varchar(255) not null,
  company_no int not null,
  PRIMARY key (
    company_account_no,
    company_balance,
    company_deposit,
    company_withdraw,
    company_history
  ),
  FOREIGN KEY (company_no) REFERENCES BJR81526.company_info(company_no) ON UPDATE RESTRICT ON DELETE CASCADE
);
create TABLE BJR81526.wallet (
  wallet_account_no varchar(255),
  wallet_balance int,
  wallet_deposit int,
  wallet_withdraw int,
  wallet_history varchar(255)
);

create TABLE BJR81526.mission_info (
    mission_no	int NOT NULL,
    mission_name	varchar(100),
    mission_category	varchar(40),
    mission_start	date,
    mission_end	date,
    mission_personnel	int,
    mission_reward	int,
    mission_ispayback	boolean,
    mission_payback	int,
    mission_survey_num	int,
    mission_survey_question	varchar(40),
    PRIMARY key (mission_no)
);

create TABLE BJR81526.mission_status (
    progress	varchar(20),
    approval	boolean,
    mission_no	int,
    FOREIGN KEY (mission_no) REFERENCES BJR81526.mission_info(mission_no) ON UPDATE RESTRICT ON DELETE CASCADE
);

create TABLE BJR81526.admin_info (
    admin_id varchar(20) not null,
    admin_pw varchar(40) not null,
    last_login_date date,
    PRIMARY key (admin_id)
);

create TABLE BJR81526.admin_accounts (
    admin_accounts_no varchar(255) not null,
    admin_balance int not null,
    admin_deposit int not null,
    admin_withdraw int not null,
    admin_history varchar(255) not null,
    admin_id varchar(20) not null,
    PRIMARY key (admin_accounts_no),
    FOREIGN KEY (admin_id) REFERENCES BJR81526.admin_info(admin_id) ON UPDATE RESTRICT ON DELETE CASCADE
);

create TABLE BJR81526.admin_shop (
    company_item varchar(40),
    user_item varchar(40)
);