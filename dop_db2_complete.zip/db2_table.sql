set character_set_client = utf8mf4;

create table knv93972.manager (
    manager_name varchar(45) not null,
    manager_email varchar(60) not null,
    manager_tel varchar(40) not null,
    primary key (
        manager_name,
        manager_email,
        manager_tel
    )
);

create table knv93972.companys (
    company_id varchar(60) not null,
    company_Bnum blob not null,
    company_tel varchar(40),
    primary key (
        company_id
    )
);

create table knv93972.missions (
    mission_no int not null default '0',
    mission_name varchar(45) not null,
    mission_tag clob not null default '(buy, eat, survey)',
    mission_date date not null,
    mission_start date not null,
    mission_end date not null,
    mission_personnel int not null,
    mission_survey_num int not null default '3',
    mission_survey_question blob not null,
    mission_state varchar(10) not null,
    company_id varchar(60),
    manager_name varchar(45) not null,
    manager_email varchar(60) not null,
    manager_tel varchar(40) not null,
    primary key (
        mission_no
    ),
    FOREIGN KEY (company_id) REFERENCES knv93972.companys(company_id) ON UPDATE RESTRICT ON DELETE CASCADE,
    FOREIGN KEY (manager_name, manager_email, manager_tel) REFERENCES knv93972.manager(manager_name, manager_email, manager_tel) ON UPDATE RESTRICT ON DELETE CASCADE
);

create table knv93972.admin (

);

create table knv93972.user (
    user_id varchar(40) not null,
     user_pwd varchar(255) not null,
     user_email varchar(60) not null,
     user_tel varchar(15) not null,

    primary key (
        user_id,
        user_tel
        )
);